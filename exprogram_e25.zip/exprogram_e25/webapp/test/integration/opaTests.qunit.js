/* global QUnit */

sap.ui.require(["exprograme25/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
