sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("exprograme25.controller.App", {
        onInit() {
        }
      });
    }
  );
  