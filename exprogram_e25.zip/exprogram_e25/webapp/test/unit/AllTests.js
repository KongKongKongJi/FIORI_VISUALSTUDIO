sap.ui.define([
	"exprogram_e25/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
