sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,JSONModel,Filter) {
        "use strict";

        return Controller.extend("exprograme25.controller.Detail", {
            onInit: function (oEvent) {

                var oTable = that.getView().byId("idTable");

                var oItem = oEvent.getSource();
                var sPath = oItem.getBindingContext().getPath();
                var modelData = oTable.getModel();
                var data = modelData.getProperty(sPath);


                this.oModel.read(sPath, {
                    // filters: [필터모델객체],
                    urlParameters: { $expand: "to_Item" },
                    success: function(oReturn) {
                        console.log("Result : ", oReturn);

                        var oTable2 = this.byId("idTable2");

                        this.getView().setModel(new JSONModel(oReturn), 'list');

                        this.oModel.setProperty("/", oReturn);
                        // this.oMainModel.setData(oReturn);
                    }.bind(this)
                });
                
            }
        });
    });
